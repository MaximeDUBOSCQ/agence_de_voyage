<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>Maldives — Agencetourisques</title>
</head>
<body><center>
	<font size="50"><font class="text-decoration-underline">Maldives</font> :</font></center>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-12 col-md-2">
	</div>
	<div class="col-12 col-md-8">
	<center>
	<p>
Les Maldives sont un État insulaire de la mer des Laquedives situé à 612 kilomètres (jusqu'à Malé) au sud-ouest de l'État du Kerala, en Inde, et à 755 kilomètres à l'ouest-sud-ouest du Sri Lanka. Le pays, constitué de 26 atolls et trois îles isolées divisés en 20 régions administratives soit 1 199 îles au total (dont à peine plus de 200 habitées en permanence), s'étire du nord au sud entre le Lakshadweep et le territoire britannique de l'océan Indien (Archipel des Chagos). Les atolls occidentaux ont leur côte ouest baignant la mer d'Arabie tandis que les atolls orientaux appartiennent en totalité à la mer des Laquedives.</p>
<p>
Cette myriade d'îles et d'îlots est disséminée sur une superficie extrêmement vaste (presque 90 000 km2) s'étendant sur plus de 800 kilomètres dans le sens latitudinal et 130 kilomètres dans le sens longitudinal. Nombre de ces îles constituent des îles-hôtel. Pour éviter de trop grandes conséquences pour l'environnement et limiter la construction d'établissements trop modernes et élitaires (clubs, résidences, etc.), le gouvernement impose de très sévères taxes sur leur réalisation dans les îles non habitées en permanence4.</p>
<p>
La capitale et plus grande ville du pays est Malé, sur l'atoll Malé du Nord. </p>
<br>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Atmosphere Kanifushi
	</center>
	<div class="bg-white rounded shadow-sm"><img src="atmosphere.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Meerufenfuchi
	</center>
	<div class="bg-white rounded shadow-sm"><img src="meeru.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Maalefushi
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Maalefushi.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Malé Atoll
	</center>
	<div class="bg-white rounded shadow-sm"><img src="MaleAtoll.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
</center>
</body>
</html>