<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>Seychelles — Agencetourisques</title>
</head>
<body><center>
	<font size="50"><font class="text-decoration-underline">Seychelles</font> :</font></center>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-12 col-md-2">
	</div>
	<div class="col-12 col-md-8">
	<center>
	<p>
Cent quinze terres émergées au milieu de l’océan Indien forment l’archipel des Seychelles. Les premières sont accrochées sous l’équateur, les plus lointaines s’approchent des côtes de Madagascar. Chacune a son identité et son charme. Presque toutes les îles des Seychelles possèdent des baies idylliques et des plages piquées de palmiers entourées de rochers polis dans diverses teintes de granit, que l’on croirait sculptés pour servir de décor de cinéma.
Près de 50 % du territoire des Seychelles est protégé dans des réserves naturelles, ce qui permet d’observer à loisir des tortues, d’innombrables poissons colorés et des oiseaux qui ne craignent pas la présence de l’homme. Chaque île mériterait une visite, mais la plupart des voyageurs ne découvrent qu’une petite partie du vaste archipel.
Un tour à Mahé, Praslin ou La Digue suffit à faire un beau voyage, mais n’oublions pas que les Seychelles possèdent bien d’autres horizons, qui portent les noms de Bird, Frégate, Poivre, Denis, Thérèse ou Alphonse...</p>
<br>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Île de frégate
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Fregate.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Anse source d'argent
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Anse.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	La digue
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Digue.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Île du nord
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Nord.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
</center>
</body>
</html>