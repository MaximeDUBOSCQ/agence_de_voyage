<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>Canada — Agencetourisques</title>
</head>
<body><center>
	<font size="50"><font class="text-decoration-underline">Canada</font> :</font></center>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-12 col-md-2">
	</div>
	<div class="col-12 col-md-8">
	<center>
	<p>
Nation de nos cousins les québécois, étendu entre les océans Atlantique et Pacifique, le Canada en impose. Sa grandeur et ses paysages impressionnent : il n’est autre que le deuxième plus grand pays du monde après la Russie. Certains clichés canadiens ne sont pas infondés : les lacs, les forêts, les montagnes et les paysages enneigés sont bien réels. La rencontre avec les ours, les baleines, et les castors aussi. Votre séjour au Canada sera rempli d’émotions et de souvenirs. Tout le monde sera conquis par ses atouts : les amoureux de la nature n’auront que l’embarras du choix face à son immensité; en hiver, les sentiers se parcourent à chiens de traîneaux, en moto-neige, ou en raquettes. Les stations de ski, elles, ne manquent pas. En été, place aux randonnées à pied ou à VTT, au rafting, kayak, mais aussi et bien sûr à la pêche. Et les inconditionnels des grandes villes reconnaîtront le style très américain des métropoles canadiennes. Les grands espaces naturels contrastent donc avec les gratte-ciel. Ici, deux langues officielles sont parlées : majoritairement l’anglais, et le français dans la région du Quebec.</p>
<br>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Fairmont le Château Frontenac
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Chateau.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Musée royale de l'Ontanrio
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Musee.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Stanley park
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Stanleypark.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Lac Moraine
	</center>
	<div class="bg-white rounded shadow-sm"><img src="LacMoraine.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
<div class="col-xl-3 col-lg-4 col-md-6 mb-4">
	<center>
	Tour du CN
	</center>
	<div class="bg-white rounded shadow-sm"><img src="Tour.jpg" alt="" class="img-fluid card-img-top">
	</div>
</div>
</center>
</body>
</html>